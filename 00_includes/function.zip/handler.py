# importeer pymysql
# (in geval van Lambda) schrijf de code en zip it.
# via de Windows Explorer

# Lambda Permissions:
# AWSLambdaVPCAccessExecutionRole

import pymysql

# Configuratie waardes
endpoint = 'awslamba-1.cjtjgfudct8k.eu-central-1.rds.amazonaws.com'
username = 'admin'
password = 'Hnk1!awslambda'
database_name = 'Transactions_prod'

# Verbinding
connection = pymysql.connect(host=endpoint, user=username, password=password,
                             db=database_name)


def lambda_handler(event, context):
    cursor = connection.cursor()
    cursor.execute('SELECT * from Transaction')

    rows = cursor.fetchall()

    for row in rows:
        print("{0} {1} {2}".format(row[0], row[1], row[2]))
