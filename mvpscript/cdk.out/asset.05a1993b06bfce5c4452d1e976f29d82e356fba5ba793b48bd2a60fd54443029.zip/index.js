"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
exports.__esModule = true;
exports.handler = void 0;
var aws_cloudformation_custom_resource_1 = require("aws-cloudformation-custom-resource");
var AWS = require("aws-sdk");
var forge = require("node-forge");
var ec2 = new AWS.EC2();
var secretsmanager = new AWS.SecretsManager();
var logger = new aws_cloudformation_custom_resource_1.StandardLogger();
var handler = function (event, context, callback) {
    new aws_cloudformation_custom_resource_1.CustomResource(context, callback, logger)
        .onCreate(Create)
        .onUpdate(Update)
        .onDelete(Delete)
        .handle(event);
};
exports.handler = handler;
function Create(event) {
    logger.info("Attempting to create EC2 Key Pair ".concat(event.ResourceProperties.Name));
    return new Promise(function (resolve, reject) {
        createKeyPair(event)
            .then(createPrivateKeySecret)
            .then(createPublicKeySecret)
            .then(exposePublicKey)
            .then(function (data) {
            resolve(data);
        })["catch"](function (err) {
            reject(err);
        });
    });
}
function Update(event) {
    logger.info("Attempting to update EC2 Key Pair ".concat(event.OldResourceProperties.Name));
    return new Promise(function (resolve, reject) {
        if (event.ResourceProperties.Name !== event.OldResourceProperties.Name) {
            reject(new Error('A Key Pair cannot be renamed. Please create a new Key Pair instead'));
        }
        else if (event.ResourceProperties.StorePublicKey !==
            event.OldResourceProperties.StorePublicKey) {
            reject(new Error('Once created, a key cannot be modified or accessed. Therefore the public key can only be stored, when the key is created.'));
        }
        else if (event.ResourceProperties.PublicKey !==
            (event.OldResourceProperties.PublicKey || '')) {
            reject(new Error('You cannot change the public key of an exiting key pair. Please delete the key pair and create a new one.'));
        }
        updateKeyPair(event)
            .then(updateKeyPairAddTags)
            .then(updateKeyPairRemoveTags)
            .then(updatePrivateKeySecret)
            .then(updatePublicKeySecret)
            .then(updateSecretsAddTags)
            .then(updateSecretsRemoveTags)
            .then(exposePublicKey)
            .then(function (data) {
            resolve(data);
        })["catch"](function (err) {
            reject(err);
        });
    });
}
function Delete(event) {
    logger.info("Attempting to delete EC2 Key Pair ".concat(event.ResourceProperties.Name));
    return new Promise(function (resolve, reject) {
        deleteKeyPair(event)
            .then(deletePrivateKeySecret)
            .then(deletePublicKeySecret)
            .then(function (data) {
            resolve(data);
        })["catch"](function (err) {
            reject(err);
        });
    });
}
function createKeyPair(event) {
    return new Promise(function (resolve, reject) {
        if (
        // public key provided, let's import
        event.ResourceProperties.PublicKey &&
            event.ResourceProperties.PublicKey.length) {
            var params = {
                KeyName: event.ResourceProperties.Name,
                PublicKeyMaterial: event.ResourceProperties.PublicKey,
                TagSpecifications: [
                    {
                        ResourceType: 'key-pair',
                        Tags: makeTags(event, event.ResourceProperties)
                    },
                ]
            };
            logger.debug("ec2.importKeyPair: ".concat(JSON.stringify(params)));
            ec2.importKeyPair(params, function (err, data) {
                if (err)
                    return reject(err);
                event.addResponseValue('KeyPairName', data.KeyName);
                event.addResponseValue('KeyPairID', data.KeyPairId);
                event.KeyFingerprint = data.KeyFingerprint;
                event.KeyMaterial = data.KeyMaterial;
                event.KeyID = data.KeyPairId;
                resolve(event);
            });
        }
        else {
            // no public key provided. create new key
            var params = {
                KeyName: event.ResourceProperties.Name,
                TagSpecifications: [
                    {
                        ResourceType: 'key-pair',
                        Tags: makeTags(event, event.ResourceProperties)
                    },
                ]
            };
            logger.debug("ec2.createKeyPair: ".concat(JSON.stringify(params)));
            ec2.createKeyPair(params, function (err, data) {
                if (err)
                    return reject(err);
                event.addResponseValue('KeyPairName', data.KeyName);
                event.addResponseValue('KeyPairID', data.KeyPairId);
                event.KeyFingerprint = data.KeyFingerprint;
                event.KeyMaterial = data.KeyMaterial;
                event.KeyID = data.KeyPairId;
                resolve(event);
            });
        }
    });
}
function updateKeyPair(event) {
    return new Promise(function (resolve, reject) {
        // there is nothing to update. a key cannot be changed
        // though we use this step to enrich the event with the keyId
        var params = {
            KeyNames: [event.ResourceProperties.Name]
        };
        logger.debug("ec2.describeKeyPairs: ".concat(JSON.stringify(params)));
        ec2.describeKeyPairs(params, function (err, data) {
            var _a;
            if (err)
                return reject(err);
            if (((_a = data.KeyPairs) === null || _a === void 0 ? void 0 : _a.length) != 1)
                return reject(new Error('Key pair was not found'));
            var id = data.KeyPairs[0].KeyPairId;
            var name = data.KeyPairs[0].KeyName;
            event.KeyID = id;
            console.log("the KEY ID IS ".concat(event.KeyID));
            event.addResponseValue('KeyPairName', name);
            event.addResponseValue('KeyPairID', id);
            resolve(event);
        });
    });
}
function updateKeyPairAddTags(event) {
    logger.info("Attempting to update tags for Key Pair ".concat(event.ResourceProperties.Name));
    return new Promise(function (resolve, reject) {
        var oldTags = makeTags(event, event.OldResourceProperties);
        var newTags = makeTags(event, event.ResourceProperties);
        if (JSON.stringify(oldTags) == JSON.stringify(newTags)) {
            logger.info("No changes of tags detected for Key Pair ".concat(event.ResourceProperties.Name, ". Not attempting any update"));
            return resolve(event);
        }
        var params = {
            Resources: [event.KeyID],
            Tags: newTags
        };
        logger.debug("ec2.createTags: ".concat(JSON.stringify(params)));
        ec2.createTags(params, function (err, _) {
            if (err)
                return reject(err);
            resolve(event);
        });
    });
}
function updateKeyPairRemoveTags(event) {
    logger.info("Attempting to remove some tags for Key Pair ".concat(event.ResourceProperties.Name));
    return new Promise(function (resolve, reject) {
        var oldTags = makeTags(event, event.OldResourceProperties);
        var newTags = makeTags(event, event.ResourceProperties);
        var tagsToRemove = getMissingTags(oldTags, newTags);
        if (JSON.stringify(oldTags) == JSON.stringify(newTags) ||
            !tagsToRemove.length) {
            logger.info("No changes of tags detected for Key Pair ".concat(event.ResourceProperties.Name, ". Not attempting any update"));
            return resolve(event);
        }
        logger.info("Will remove the following tags: ".concat(JSON.stringify(tagsToRemove)));
        var params = {
            Resources: [event.KeyID],
            Tags: tagsToRemove.map(function (key) {
                return {
                    Key: key,
                    Value: event.OldResourceProperties.Tags[key]
                };
            })
        };
        logger.debug("ec2.deleteTags: ".concat(JSON.stringify(params)));
        ec2.deleteTags(params, function (err, _) {
            if (err)
                reject(err);
            else
                resolve(event);
        });
    });
}
function deleteKeyPair(event) {
    return new Promise(function (resolve, reject) {
        var params = {
            KeyName: event.ResourceProperties.Name
        };
        logger.debug("ec2.deleteKeyPair: ".concat(JSON.stringify(params)));
        ec2.deleteKeyPair(params, function (err, data) {
            if (err)
                return reject(err);
            event.addResponseValue('KeyPairName', event.ResourceProperties.Name);
            resolve(event);
        });
    });
}
function createPrivateKeySecret(event) {
    return new Promise(function (resolve, reject) {
        if (event.ResourceProperties.PublicKey) {
            event.addResponseValue('PrivateKeyARN', null);
            return resolve(event);
        }
        var params = {
            Name: "".concat(event.ResourceProperties.SecretPrefix).concat(event.ResourceProperties.Name, "/private"),
            Description: "".concat(event.ResourceProperties.Description, " (Private Key)"),
            SecretString: event.KeyMaterial,
            KmsKeyId: event.ResourceProperties.KmsPrivate,
            Tags: makeTags(event, event.ResourceProperties)
        };
        logger.debug("secretsmanager.createSecret: ".concat(JSON.stringify(params)));
        secretsmanager.createSecret(params, function (err, data) {
            if (err)
                return reject(err);
            event.addResponseValue('PrivateKeyARN', data.ARN);
            resolve(event);
        });
    });
}
function createPublicKeySecret(event) {
    return new Promise(function (resolve, reject) {
        return __awaiter(this, void 0, void 0, function () {
            var publicKey, err_1, params;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!event.ResourceProperties.PublicKey.length) return [3 /*break*/, 1];
                        publicKey = event.ResourceProperties.PublicKey;
                        return [3 /*break*/, 4];
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, makePublicKey(event)];
                    case 2:
                        publicKey = _a.sent();
                        return [3 /*break*/, 4];
                    case 3:
                        err_1 = _a.sent();
                        return [2 /*return*/, reject(err_1)];
                    case 4:
                        if (event.ResourceProperties.StorePublicKey !== 'true') {
                            return [2 /*return*/, resolve(event)];
                        }
                        params = {
                            Name: "".concat(event.ResourceProperties.SecretPrefix).concat(event.ResourceProperties.Name, "/public"),
                            Description: "".concat(event.ResourceProperties.Description, " (Public Key)"),
                            SecretString: publicKey,
                            KmsKeyId: event.ResourceProperties.KmsPublic,
                            Tags: makeTags(event, event.ResourceProperties)
                        };
                        logger.debug("secretsmanager.createSecret: ".concat(JSON.stringify(params)));
                        secretsmanager.createSecret(params, function (err, data) {
                            if (err)
                                return reject(err);
                            event.addResponseValue('PublicKeyARN', data.ARN);
                            resolve(event);
                        });
                        return [2 /*return*/];
                }
            });
        });
    });
}
function updatePrivateKeySecret(event) {
    return new Promise(function (resolve, reject) {
        var params = {
            SecretId: "".concat(event.ResourceProperties.SecretPrefix).concat(event.ResourceProperties.Name, "/private"),
            Description: "".concat(event.ResourceProperties.Description, " (Private key)"),
            KmsKeyId: event.ResourceProperties.KmsPrivate
        };
        logger.debug("secretsmanager.updateSecret: ".concat(JSON.stringify(params)));
        secretsmanager.updateSecret(params, function (err, data) {
            if (err)
                return reject(err);
            event.addResponseValue('PrivateKeyARN', data.ARN);
            resolve(event);
        });
    });
}
function updatePublicKeySecret(event) {
    return new Promise(function (resolve, reject) {
        var arn = "".concat(event.ResourceProperties.SecretPrefix).concat(event.ResourceProperties.Name, "/public");
        secretExists(arn).then(function (exists) {
            if (!exists) {
                // no public key stored. nothing to do
                return resolve(event);
            }
            var params = {
                SecretId: arn,
                Description: "".concat(event.ResourceProperties.Description, " (Public Key)"),
                KmsKeyId: event.ResourceProperties.KmsPublic
            };
            logger.debug("secretsmanager.updateSecret: ".concat(JSON.stringify(params)));
            secretsmanager.updateSecret(params, function (err, data) {
                if (err)
                    return reject(err);
                event.addResponseValue('PublicKeyARN', data.ARN);
                resolve(event);
            });
        });
    });
}
function updateSecretsAddTags(event) {
    var secretPrivateKey = "".concat(event.ResourceProperties.SecretPrefix).concat(event.ResourceProperties.Name, "/private");
    var secretPublicKey = "".concat(event.ResourceProperties.SecretPrefix).concat(event.ResourceProperties.Name, "/public");
    return new Promise(function (resolve, reject) {
        updateSecretAddTags(secretPrivateKey, event).then(function (event) {
            secretExists(secretPublicKey).then(function (exists) {
                if (!exists) {
                    // no public key stored. nothing to do
                    return resolve(event);
                }
                updateSecretAddTags(secretPublicKey, event)
                    .then(function (event) {
                    resolve(event);
                })["catch"](function (err) {
                    reject(err);
                });
            });
        });
    });
}
function updateSecretAddTags(secretId, event) {
    logger.info("Attempting to update tags for secret ".concat(secretId));
    return new Promise(function (resolve, reject) {
        var oldTags = makeTags(event, event.OldResourceProperties);
        var newTags = makeTags(event, event.ResourceProperties);
        if (JSON.stringify(oldTags) == JSON.stringify(newTags)) {
            logger.info("No changes of tags detected for secret ".concat(secretId, ". Not attempting any update"));
            return resolve(event);
        }
        var params = {
            SecretId: secretId,
            Tags: newTags
        };
        logger.debug("secretsmanager.tagResource: ".concat(JSON.stringify(params)));
        secretsmanager.tagResource(params, function (err, _) {
            if (err)
                return reject(err);
            resolve(event);
        });
    });
}
function updateSecretsRemoveTags(event) {
    var secretPrivateKey = "".concat(event.ResourceProperties.SecretPrefix).concat(event.ResourceProperties.Name, "/private");
    var secretPublicKey = "".concat(event.ResourceProperties.SecretPrefix).concat(event.ResourceProperties.Name, "/public");
    return new Promise(function (resolve, reject) {
        updateSecretRemoveTags(secretPrivateKey, event).then(function (event) {
            secretExists(secretPublicKey).then(function (exists) {
                if (!exists) {
                    // no public key stored. nothing to do
                    return resolve(event);
                }
                updateSecretRemoveTags(secretPublicKey, event)
                    .then(function (event) {
                    resolve(event);
                })["catch"](function (err) {
                    reject(err);
                });
            });
        });
    });
}
function getPrivateKey(event) {
    return new Promise(function (resolve, reject) {
        var params = {
            SecretId: "".concat(event.ResourceProperties.SecretPrefix).concat(event.ResourceProperties.Name, "/private")
        };
        logger.debug("secretsmanager.getSecretValue: ".concat(JSON.stringify(params)));
        secretsmanager.getSecretValue(params, function (err, data) {
            if (err)
                return reject(err);
            resolve(data.SecretString);
        });
    });
}
function makePublicKey(event) {
    return new Promise(function (resolve, reject) {
        return __awaiter(this, void 0, void 0, function () {
            var _a, err_2, privateKey, forgePublicKey, publicKey;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (!(typeof event.KeyMaterial == 'undefined')) return [3 /*break*/, 4];
                        _b.label = 1;
                    case 1:
                        _b.trys.push([1, 3, , 4]);
                        _a = event;
                        return [4 /*yield*/, getPrivateKey(event)];
                    case 2:
                        _a.KeyMaterial = _b.sent();
                        return [3 /*break*/, 4];
                    case 3:
                        err_2 = _b.sent();
                        return [2 /*return*/, reject(err_2)];
                    case 4:
                        privateKey = forge.pki.privateKeyFromPem(event.KeyMaterial);
                        forgePublicKey = forge.pki.rsa.setPublicKey(privateKey.n, privateKey.e);
                        if (event.ResourceProperties.PublicKeyFormat === 'PEM') {
                            publicKey = forge.pki.publicKeyToPem(forgePublicKey);
                        }
                        else if (event.ResourceProperties.PublicKeyFormat === 'OPENSSH') {
                            publicKey = forge.ssh.publicKeyToOpenSSH(forgePublicKey);
                        }
                        else {
                            reject(new Error("Unsupported public key format ".concat(event.ResourceProperties.PublicKeyFormat)));
                        }
                        resolve(publicKey);
                        return [2 /*return*/];
                }
            });
        });
    });
}
function exposePublicKey(event) {
    return new Promise(function (resolve, reject) {
        return __awaiter(this, void 0, void 0, function () {
            var publicKey, err_3;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(event.ResourceProperties.ExposePublicKey == 'true')) return [3 /*break*/, 7];
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 5, , 6]);
                        publicKey = void 0;
                        if (!event.ResourceProperties.PublicKey.length) return [3 /*break*/, 2];
                        publicKey = event.ResourceProperties.PublicKey;
                        return [3 /*break*/, 4];
                    case 2: return [4 /*yield*/, makePublicKey(event)];
                    case 3:
                        publicKey = _a.sent();
                        _a.label = 4;
                    case 4:
                        event.addResponseValue('PublicKeyValue', publicKey);
                        return [3 /*break*/, 6];
                    case 5:
                        err_3 = _a.sent();
                        return [2 /*return*/, reject(err_3)];
                    case 6: return [3 /*break*/, 8];
                    case 7:
                        event.addResponseValue('PublicKeyValue', 'Not requested - Set ExposePublicKey to true');
                        _a.label = 8;
                    case 8:
                        resolve(event);
                        return [2 /*return*/];
                }
            });
        });
    });
}
function updateSecretRemoveTags(secretId, event) {
    logger.info("Attempting to remove some tags for secret ".concat(secretId));
    return new Promise(function (resolve, reject) {
        var oldTags = makeTags(event, event.OldResourceProperties);
        var newTags = makeTags(event, event.ResourceProperties);
        var tagsToRemove = getMissingTags(oldTags, newTags);
        if (JSON.stringify(oldTags) == JSON.stringify(newTags) ||
            !tagsToRemove.length) {
            logger.info("No changes of tags detected for secret ".concat(secretId, ". Not attempting any update"));
            return resolve(event);
        }
        logger.info("Will remove the following tags: ".concat(JSON.stringify(tagsToRemove)));
        var params = {
            SecretId: secretId,
            TagKeys: tagsToRemove
        };
        logger.debug("secretsmanager.untagResource: ".concat(JSON.stringify(params)));
        secretsmanager.untagResource(params, function (err, _) {
            if (err)
                reject(err);
            else
                resolve(event);
        });
    });
}
function deletePrivateKeySecret(event) {
    return new Promise(function (resolve, reject) {
        return __awaiter(this, void 0, void 0, function () {
            var arn;
            return __generator(this, function (_a) {
                arn = "".concat(event.ResourceProperties.SecretPrefix).concat(event.ResourceProperties.Name, "/private");
                secretExists(arn)
                    .then(function (exists) {
                    if (!exists) {
                        // no private key stored. nothing to do
                        return resolve(event);
                    }
                    deleteSecret(arn, event)
                        .then(function (data) {
                        event.addResponseValue('PrivateKeyARN', data.ARN);
                        resolve(event);
                    })["catch"](function (err) {
                        reject(err);
                    });
                })["catch"](function (err) {
                    reject(err);
                });
                return [2 /*return*/];
            });
        });
    });
}
function deletePublicKeySecret(event) {
    return new Promise(function (resolve, reject) {
        return __awaiter(this, void 0, void 0, function () {
            var arn;
            return __generator(this, function (_a) {
                arn = "".concat(event.ResourceProperties.SecretPrefix).concat(event.ResourceProperties.Name, "/public");
                secretExists(arn)
                    .then(function (exists) {
                    if (!exists) {
                        // no public key stored. nothing to do
                        return resolve(event);
                    }
                    deleteSecret(arn, event)
                        .then(function (data) {
                        event.addResponseValue('PublicKeyARN', data.ARN);
                        resolve(event);
                    })["catch"](function (err) {
                        reject(err);
                    });
                })["catch"](function (err) {
                    reject(err);
                });
                return [2 /*return*/];
            });
        });
    });
}
function secretExists(name) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            return [2 /*return*/, new Promise(function (resolve, reject) {
                    return __awaiter(this, void 0, void 0, function () {
                        var params;
                        return __generator(this, function (_a) {
                            params = {
                                Filters: [
                                    {
                                        Key: 'name',
                                        Values: [name]
                                    },
                                ]
                            };
                            logger.debug("secretsmanager.listSecrets: ".concat(JSON.stringify(params)));
                            return [2 /*return*/, secretsmanager.listSecrets(params, function (err, data) {
                                    if (err)
                                        return reject(err);
                                    resolve(data.SecretList.length > 0);
                                })];
                        });
                    });
                })];
        });
    });
}
function deleteSecret(secretId, event) {
    var params = {
        SecretId: secretId
    };
    var removeKeySecretsAfterDays = event.ResourceProperties
        .RemoveKeySecretsAfterDays;
    if (removeKeySecretsAfterDays > 0) {
        params.RecoveryWindowInDays =
            event.ResourceProperties.RemoveKeySecretsAfterDays;
    }
    else {
        params.ForceDeleteWithoutRecovery = true;
    }
    logger.debug("secretsmanager.deleteSecret: ".concat(JSON.stringify(params)));
    return secretsmanager.deleteSecret(params).promise();
}
function makeTags(event, properties) {
    var tags = [
        {
            Key: 'aws-cloudformation:stack-id',
            Value: event.StackId
        },
        {
            Key: 'aws-cloudformation:stack-name',
            Value: properties.StackName
        },
        {
            Key: 'aws-cloudformation:logical-id',
            Value: event.LogicalResourceId
        },
    ];
    if ('Tags' in properties) {
        Object.keys(properties.Tags).forEach(function (key) {
            tags.push({
                Key: key,
                Value: properties.Tags[key]
            });
        });
    }
    return tags;
}
function getMissingTags(oldTags, newTags) {
    var missing = oldTags.filter(missingTags(newTags));
    return missing.map(function (tag) {
        return tag.Key;
    });
}
function missingTags(newTags) {
    return function (currentTag) {
        return (newTags.filter(function (newTag) {
            return newTag.Key == currentTag.Key;
        }).length == 0);
    };
}
